<?php $__env->startSection('title', 'Create User'); ?>
<?php $__env->startSection('description', 'Please make sure to check all input'); ?>
<?php $__env->startSection('button'); ?>
  <a href="<?php echo e(url('/manager/user')); ?>" class="btn btn-info btn-xs no-border">Back</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid container-fixed-lg">
    <div class="row">
      <div class="col-lg-12">
        <div class="panel panel-default">
          <div class="panel-body">

            <?php echo Form::open(['url' => 'manager/user', 'id' => 'formValidate', 'files' => true]); ?>


            <div class="row">
              <div class="col-md-6">
                <div aria-required="true" class="form-group form-group-default <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                  <?php echo Form::label('name', "name"); ?>

                  <?php echo Form::text('name', null, ['class' => 'form-control input-md', 'required' => 'required', 'placeholder' => "name"]); ?>

                  <?php echo $errors->first('name', '<label class="error">:message</label>'); ?>

                </div>

                <div aria-required="true" class="form-group form-group-default <?php echo e($errors->has('username') ? 'has-error' : ''); ?>">
                  <?php echo Form::label('username', "username"); ?>

                  <?php echo Form::text('username', null, ['class' => 'form-control input-md', 'required' => 'required', 'placeholder' => "username"]); ?>

                  <?php echo $errors->first('username', '<label class="error">:message</label>'); ?>

                </div>

                <div aria-required="true" class="form-group form-group-default <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
                  <?php echo Form::label('password', "password"); ?>

                  <?php echo Form::password('password', ['class' => 'form-control input-md', 'required' => 'required', 'placeholder' => "password"]); ?>

                  <?php echo $errors->first('password', '<label class="error">:message</label>'); ?>

                </div>
              </div>
              <div class="col-md-6">
                <div aria-required="true" class="form-group form-group-default <?php echo e($errors->has('phone') ? 'has-error' : ''); ?>">
                  <?php echo Form::label('phone', "phone number"); ?>

                  <?php echo Form::number('phone', null, ['class' => 'form-control input-md', 'required' => 'required', 'placeholder' => "phone number"]); ?>

                  <?php echo $errors->first('phone', '<label class="error">:message</label>'); ?>

                </div>

                <div aria-required="true" class="form-group form-group-default <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                  <?php echo Form::label('email', "email"); ?>

                  <?php echo Form::email('email', null, ['class' => 'form-control input-md', 'required' => 'required', 'placeholder' => "email"]); ?>

                  <?php echo $errors->first('email', '<label class="error">:message</label>'); ?>

                </div>
                <div aria-required="true" class="form-group form-group-default <?php echo e($errors->has('role') ? 'has-error' : ''); ?>">
                  <?php echo Form::label('role', "role"); ?>

                  <?php echo Form::select('role', $roles, null, ['class' => 'form-control input-md', 'required' => 'required', 'placeholder' => "role"]); ?>

                  <?php echo $errors->first('role', '<label class="error">:message</label>'); ?>

                </div>


              </div>

            </div>

            <div class="pull-left m-b-20">
              <div class="checkbox check-success">
                <input id="checkbox-agree" type="checkbox" required> <label for="checkbox-agree"><small>Saya sudah mengecek data sebelum menyimpan</small></label>
              </div>
            </div>

            <br/>

            <button class="btn btn-default btn-rounded btn-sm p-l-30 p-r-30 m-r-10" type="reset">CLEAR</button>
            <?php echo Form::submit('CREATE', ['type' => 'submit', 'class' => 'btn btn-success btn-rounded btn-sm p-l-30 p-r-30']); ?>



            <?php echo Form::close(); ?>

          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
  <script type="text/javascript">
    $(document).ready(function() {
      $('#formValidate').validate();

    });
  </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('manager.layouts.frame', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>