<?php $__env->startSection('title', 'Block'); ?>
<?php $__env->startSection('description', 'Block Management'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid container-fixed-lg">
        <div class="row">

            <div class="col-lg-12">

                <div class="panel panel-default">
                    <div class="panel-heading">
                        <div class="panel-title">
                            <h4 class="m-t-0">Block</h4>
                        </div>
                        <a href="<?php echo e(url('manager/block/create')); ?>" class="btn btn-default pull-right btn-rounded btn-xs" type="button" style="width:28px;height:28px;"><i class="fa fa-plus" style="width:8px;"></i></a>
                    </div>
                    <div class="panel-body no-padding" style="background: #FFF">
                        <div class="row">
                            <table class="table table-hover de-left m-b-0 b-t-1">
                                <tbody>
                                <tr>
                                    <td width="10%">
                                        Action
                                    </td>
                                    <td>Name</td>
                                    <td width="10%" class="text-right">Jumlah</td>
                                    <td width="10%">Akad</td>
                                    <td width="10%">Kosong</td>
                                    <td width="10%">Terisi</td>
                                </tr>
                                <?php if(count($blocks)): ?>
                                    <?php $__currentLoopData = $blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr id="<?php echo e($block->id); ?>">
                                            <td>
                                                <a onClick="deleteData(<?php echo e($block->id); ?>)" class="btn btn-default btn-rounded btn-xs" type="button" style="width:28px;height:28px;margin-right:4px;"><i class="fa fa-trash" style="width:8px;"></i></a>
                                            </td>
                                            <td class="font-montserrat all-caps fs-12" style="white-space: nowrap;"><?php echo e($block->name); ?></td>
                                            <td class="text-right b-r b-dashed b-grey" ><span class="hint-text small"><?php echo e(count($block->houses)); ?></span></td>
                                            <td><span class="font-montserrat fs-10"><?php echo e(count($block->housesAkad)); ?></span></td>
                                            <td><span class="font-montserrat fs-10"><?php echo e(count($block->housesKosong)); ?></span></td>
                                            <td><span class="font-montserrat fs-10"><?php echo e(count($block->housesIsi)); ?></span></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="6" style="background: #EEE;padding: 10px 20px;">
                                            Kosong
                                        </td>
                                    </tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                    <div class="panel-footer" style="background: #FFF;color: #101010;font-size: 13px;font-weight: 300">
                        <?php echo e((count($blocks) > 15) ? $blocks->links() : "Number of data: " . count($blocks)); ?>

                    </div>
                </div>
            </div>

        </div>
    </div>
    <input type="hidden" id="deleteID" />
<?php $__env->stopSection(); ?>


<?php $__env->startPush("script"); ?>
<script>
    function deleteData(id) {
        $('#modalDelete').modal('show');
        $('#deleteID').val(id);
    }

    function hapus(){
        $('#modalDelete').modal('hide');
        var id = $('#deleteID').val();
        $.ajax({
            url: '<?php echo e(url("manager/block")); ?>' + "/" + id + '?' + $.param({"_token" : '<?php echo e(csrf_token()); ?>' }),
            type: 'DELETE',
            complete: function(data) {
                $('#' + id).remove();
            }
        });
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('manager.layouts.frame', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>