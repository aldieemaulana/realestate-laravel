<li class="m-t-30">
    <a class="{{ (Request::is('*')) ? 'active' : ''}}" href="{{ url('/') }}"><span class="title">Dashboard</span></a> <span class=" {{ (Request::is('*')) ? 'bg-success' : ''}} icon-thumbnail"><i class="pg-home"></i></span>
</li>
