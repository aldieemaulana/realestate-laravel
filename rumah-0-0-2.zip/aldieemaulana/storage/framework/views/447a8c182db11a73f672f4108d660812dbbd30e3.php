<?php $__env->startSection('title', 'Edit Location'); ?>
<?php $__env->startSection('description', 'Please make sure to check all input'); ?>
<?php $__env->startSection('button'); ?>
  <a href="<?php echo e(url('/manager/location')); ?>" class="btn btn-info btn-xs no-border">Back</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid container-fixed-lg">
    <div class="row">
      <div class="col-lg-12">
        <div class="panel panel-default">
          <div class="panel-body">

            <?php echo Form::model($information, [
              'method' => 'PATCH',
              'url' => ['/manager/location', $information->id],
              'files' => true,
              'id' => 'formValidate',
              ]); ?>


              <div class="row">
                <div class="col-md-12">
                  <div aria-required="true" class="form-group form-group-default required <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                      <?php echo Form::label('name', "Nama"); ?>

                      <?php echo Form::text('name', null, ['class' => 'form-control input-md', 'required' => 'required', 'placeholder' => "Nama"]); ?>

                  </div>
                  <?php echo $errors->first('name', '<label class="error">:message</label>'); ?>

                </div>

              </div>


              <br/>

              <button class="btn btn-default btn-rounded btn-sm p-l-30 p-r-30 m-r-10" type="reset">CLEAR</button>
              <?php echo Form::submit('SAVE', ['type' => 'submit', 'class' => 'btn btn-success btn-rounded btn-sm p-l-30 p-r-30']); ?>



              <?php echo Form::close(); ?>

          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
  <script type="text/javascript">
    $(document).ready(function() {
      $('#formValidate').validate();

    });
  </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('manager.layouts.frame', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>