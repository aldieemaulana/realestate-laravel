<!DOCTYPE html>
<html lang="en">
  <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, shrink-to-fit=no"/>
      <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
      <link rel="apple-touch-icon" sizes="57x57" href="<?php echo e(url('img/ic/apple-icon-57x57.png')); ?>">
      <link rel="apple-touch-icon" sizes="60x60" href="<?php echo e(url('img/ic/apple-icon-60x60.png')); ?>">
      <link rel="apple-touch-icon" sizes="72x72" href="<?php echo e(url('img/ic/apple-icon-72x72.png')); ?>">
      <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(url('img/ic/apple-icon-76x76.png')); ?>">
      <link rel="apple-touch-icon" sizes="114x114" href="<?php echo e(url('img/ic/apple-icon-114x114.png')); ?>">
      <link rel="apple-touch-icon" sizes="120x120" href="<?php echo e(url('img/ic/apple-icon-120x120.png')); ?>">
      <link rel="apple-touch-icon" sizes="144x144" href="<?php echo e(url('img/ic/apple-icon-144x144.png')); ?>">
      <link rel="apple-touch-icon" sizes="152x152" href="<?php echo e(url('img/ic/apple-icon-152x152.png')); ?>">
      <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(url('img/ic/apple-icon-180x180.png')); ?>">
      <link rel="icon" type="image/png" sizes="192x192"  href="<?php echo e(url('img/ic/android-icon-192x192.png')); ?>">
      <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(url('img/ic/favicon-32x32.png')); ?>">
      <link rel="icon" type="image/png" sizes="96x96" href="<?php echo e(url('img/ic/favicon-96x96.png')); ?>">
      <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(url('img/ic/favicon-16x16.png')); ?>">
      <link rel="manifest" href="<?php echo e(url('img/ic/manifest.json')); ?>">
      <meta name="msapplication-TileColor" content="#ffffff">
      <meta name="msapplication-TileImage" content="<?php echo e(url('img/ic/ms-icon-144x144.png')); ?>">
      <meta name="theme-color" content="#ffffff">
      <meta content="" name="description"/>
      <meta content="" name="author"/>

      <title> <?php echo $__env->yieldContent('title'); ?><?php echo e(config('app.name', '')); ?></title>

      <?php $__env->startSection('header'); ?>
          <?php echo $__env->make('default.components.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->yieldSection(); ?>

  </head>

  <body class="fixed-header" style="background-color: #f2f2f2;overflow-x: hidden">

      <?php echo $__env->yieldContent('button'); ?>
      <div style="background: rgba(0,0,0,.8);min-height: 100vh;">
        <div class="lock-container full-height">
          <div class="container-sm-height full-height sm-p-t-50">
            <div class="row row-sm-height">
              <div class="col-sm-9 col-sm-height col-middle">

                <?php echo $__env->yieldContent("content"); ?>

              </div>
            </div>
          </div>
        </div>
        <div class="row text-center">
          <div class="text-white small" style="margin-top: 5.5vh;font-family: 'Lato', sans-serif;">
            <ul class="list-inline" style="margin-bottom: 0px;">
              <li><a href="http://laravel.com" target="_blank" class="text-white text-bold-ter">Laravel</a></li>
              <li> | </li>
              <li><a href="http://aldieemaulana.com" target="_blank" class="text-white text-bold-ter">Developer</a></li>
              <li> | </li>
              <li><a href="http://sigmaid.net" target="_blank" class="text-white text-bold-ter">Project Owner</a></li>
            </ul>
            Copyright &copy; 2017 aldieemaulana, All rights reserved
          </div>
        </div>
      </div>

      <?php $__env->startSection('scripts'); ?>
          <?php echo $__env->make('default.components.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->yieldPushContent('script'); ?>

  </body>
</html>
