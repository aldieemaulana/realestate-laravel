<script data-pace-options='{ "ajax": true }' src="{{ url('plugins/pace/pace.min.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/jquery/jquery-1.11.1.min.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/modernizr.custom.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/jquery-ui/jquery-ui.min.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/bootstrapv3/js/bootstrap.min.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/jquery/jquery-easy.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/jquery-unveil/jquery.unveil.min.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/jquery-bez/jquery.bez.min.js') }}"></script>
<script src="{{ url('plugins/jquery-ios-list/jquery.ioslist.min.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/jquery-actual/jquery.actual.min.js') }}"></script>
<script src="{{ url('plugins/jquery-scrollbar/jquery.scrollbar.min.js') }}"></script>
<script src="{{ url('plugins/select2/js/select2.full.min.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/classie/classie.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/switchery/js/switchery.min.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/nvd3/lib/d3.v3.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/nvd3/nv.d3.min.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/nvd3/src/utils.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/nvd3/src/tooltip.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/nvd3/src/interactiveLayer.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/nvd3/src/models/axis.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/nvd3/src/models/line.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/nvd3/src/models/lineWithFocusChart.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/mapplic/js/hammer.js') }}"></script>
<script src="{{ url('plugins/mapplic/js/jquery.mousewheel.js') }}"></script>
<script src="{{ url('plugins/mapplic/js/mapplic.js') }}"></script>
<script src="{{ url('plugins/rickshaw/rickshaw.min.js') }}"></script>
<script src="{{ url('plugins/summernote/js/summernote.min.js') }}"></script>
<script src="{{ url('plugins/jquery-autonumeric/autoNumeric.js') }}"></script>
<script src="{{ url('plugins/jquery-metrojs/MetroJs.min.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/jquery-sparkline/jquery.sparkline.min.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/skycons/skycons.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/dragula/dragula.min.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/bootstrap-datepicker/js/bootstrap-datepicker.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/bootstrap-timepicker/bootstrap-timepicker.min.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/jquery-datatable/media/js/jquery.dataTables.min.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/jquery-datatable/extensions/TableTools/js/dataTables.tableTools.min.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/jquery-datatable/extensions/Bootstrap/jquery-datatable-bootstrap.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/jquery-datatable/extensions/FixedHeader/js/dataTables.fixedHeader.min.js') }}"></script>
<script src="{{ url('plugins/jquery-datatable/extensions/Buttons/js/dataTables.buttons.min.js') }}"></script>
<script src="{{ url('plugins/jquery-datatable/extensions/Buttons/js/buttons.bootstrap.min.js') }}"></script>
<script src="{{ url('plugins/jquery-datatable/extensions/Buttons/js/buttons.flash.min.js') }}"></script>
<script src="{{ url('plugins/jquery-datatable/extensions/Buttons/js/jszip.js') }}"></script>
<script src="{{ url('plugins/jquery-datatable/extensions/Buttons/js/buttons.html5.min.js') }}"></script>
<script src="{{ url('plugins/jquery-datatable/extensions/Buttons/js/buttons.print.min.js') }}"></script>
<script src="{{ url('plugins/jquery-datatable/extensions/Buttons/js/buttons.colVis.min.js') }}"></script>
<script src="{{ url('plugins/datatables-responsive/js/datatables.responsive.js') }}" type="text/javascript"></script>
<script src="{{ url('plugins/datatables-responsive/js/lodash.min.js') }}" type="text/javascript"></script>
<script type="text/javascript" src="{{url('plugins/jquery-validation/js/jquery.validate.min.js')}}"></script>
<script src="{{ url('js/pages.min.js') }}"></script>
<script src="{{ url('js/moment.js') }}"></script>
<script src="{{ url('js/scripts.js') }}"></script>

<script>
    $.fn.dataTable.ext.errMode = function ( settings, helpPage, message ) {
        console.log(message);
    };
</script>
