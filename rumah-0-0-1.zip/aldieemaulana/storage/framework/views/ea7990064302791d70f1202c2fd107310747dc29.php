<li class="m-t-30">
    <a class="<?php echo e((Request::is('manager/dashboard*')) ? 'active' : ''); ?>" href="<?php echo e(url('manager/dashboard')); ?>"><span class="title">Dashboard</span></a> <span class=" <?php echo e((Request::is('manager/dashboard*')) ? 'bg-success' : ''); ?> icon-thumbnail"><i class="pg-home"></i></span>
</li>

<li>
    <a class="<?php echo e((Request::is('manager/block*')) ? 'active' : ''); ?>" href="<?php echo e(url('manager/block')); ?>">
        <span class="title">Rumah</span>
    </a>
    <span class=" <?php echo e((Request::is('manager/block*')) ? 'bg-success' : ''); ?> icon-thumbnail"><i class="fa fa-institution"></i></span>
</li>
