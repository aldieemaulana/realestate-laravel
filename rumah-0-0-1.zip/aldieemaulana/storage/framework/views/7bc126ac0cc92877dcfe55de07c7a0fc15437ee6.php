
<?php $__env->startSection('title', 'Dashboard @ruma'); ?>
<?php $__env->startSection('description'); ?>
    @ruma  management, <label class="kosong">Kosong</label> | <label class="akad">Akad</label> | <label class="isi">Terisi</label>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="container-fluid container-fixed-lg">
        <div class="row">

            <div class="col-lg-12">
                <?php $__currentLoopData = $blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="panel panel-default">
                    <div class="panel-body" style="background: #FFF;">
                        <h5>Blok, <?php echo e($block->name); ?>,
                            <small class="pull-right m-t-10">
                                Jumlah: <b><?php echo e(count($block->houses)); ?></b> |
                                Terisi: <b><?php echo e(count($block->housesIsi)); ?></b> |
                                Akad: <b><?php echo e(count($block->housesAkad)); ?></b> |
                                Kosong: <b><?php echo e(count($block->housesKosong)); ?></b>
                            </small></h5>
                        <hr/>
                        <div>
                            <div class="row m-t-20">
                            <?php $__currentLoopData = $block->houses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $house): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-xs-4 col-md-1 col-sm-2 text-center">
                                        <div class="wrap <?php echo e($house->status); ?>" data-placement="left"
                                             data-toggle="tooltip" title="<?php echo e(ucwords($house->status)); ?>">
                                            <div class="col-xs-4 indicator <?php echo e(($house->indicator_satu) ? "done" : ''); ?>"
                                                 data-toggle="tooltip" title="<?php echo e(($house->indicator_satu) ? " Oke" : 'Satu!'); ?>"></div>
                                            <div class="col-xs-4 indicator <?php echo e(($house->indicator_dua) ? "done" : ''); ?>"
                                                 data-toggle="tooltip" title="<?php echo e(($house->indicator_dua) ? " Oke" : 'Dua!'); ?>"></div>
                                            <div class="col-xs-4 indicator <?php echo e(($house->indicator_tiga) ? "done" : ''); ?>"
                                                 data-toggle="tooltip" title="<?php echo e(($house->indicator_tiga) ? "Oke" : 'Tiga!'); ?>"></div>
                                            <h5><?php echo e($house->number); ?></h5>
                                        </div>
                                    </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>

                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('manager.layouts.frame', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>