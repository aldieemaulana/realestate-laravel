@extends('cms.layouts.frame')
@section('title', 'Edit Gallery')
@section('description', 'Please make sure to check all input')
@section('button')
  <a href="{{ url('/cms/gallery') }}" class="btn btn-info btn-xs no-border">Back</a>
@endsection

@section('content')
  <div class="container-fluid container-fixed-lg">
    <div class="row">
      <div class="col-lg-12">
        <div class="panel panel-default">
          <div class="panel-body">
            {!! Form::model($information, [
              'method' => 'PATCH',
              'url' => ['/cms/gallery', $information->id],
              'files' => true,
              'id' => 'formValidate',
              ]) !!}

              <div class="row">
                <div class="col-md-4">
                  <div aria-required="true" class="form-group form-group-default required {{ $errors->has('section_title') ? 'has-error' : ''}}">
                      {!! Form::label('section_title', "title") !!}
                      {!! Form::text('section_title', null, ['class' => 'form-control input-md', 'required' => 'required', 'placeholder' => "Title"]) !!}
                  </div>
                  {!! $errors->first('section_title', '<label class="error">:message</label>') !!}
                </div>

                <div class="col-md-2">
                  <div aria-required="true" class="form-group form-group-default required {{ $errors->has('section_order') ? 'has-error' : ''}}">
                      {!! Form::label('section_order', "order") !!}
                      {!! Form::number('section_order', null, ['class' => 'form-control input-md', 'required' => 'required', 'placeholder' => "Order"]) !!}
                  </div>
                  {!! $errors->first('section_order', '<label class="error">:message</label>') !!}
                </div>

                <div class="col-md-6">
                  <div aria-required="true" class="form-group form-group-default  {{ $errors->has('section_subtitle') ? 'has-error' : ''}}">
                      {!! Form::label('section_subtitle', "photo") !!}
                      {!! Form::file('section_subtitle', null, ['class' => 'form-control input-md', 'placeholder' => "Photo"]) !!}
                  </div>
                  {!! $errors->first('section_subtitle', '<label class="error">:message</label>') !!}
                </div>
              </div>

              <div class="row" style="background-image: url({{ url('files/sections/galleries/'.$information->section_image) }});background-position: center; background-size: cover;height: 450px">
                <input type="hidden" name="old_section_image" value="{{ $information->section_image }}"/>
              </div>

              <br/>

              <div class="pull-left m-b-20">
                  <div class="checkbox check-success">
                      <input id="checkbox-agree" type="checkbox" required> <label for="checkbox-agree"><small>Saya sudah mengecek data sebelum menyimpan</small></label>
                  </div>
              </div>

              <br/>

              <button class="btn btn-default btn-rounded btn-sm p-l-30 p-r-30 m-r-10" type="reset">CLEAR</button>
              {!! Form::submit('UPDATE', ['type' => 'submit', 'class' => 'btn btn-success btn-rounded btn-sm p-l-30 p-r-30']) !!}


              {!! Form::close() !!}
          </div>
        </div>
      </div>
    </div>
  </div>
@endsection

@push('script')
  <script type="text/javascript">
    $(document).ready(function() {
      $('#formValidate').validate();

    });
  </script>
@endpush
