@extends('manager.layouts.frame')
@section('title', 'Dashboard @ruma')
@section('description')
    @ruma management, <label class="kosong">Kosong</label> | <label class="akad">Akad</label> | <label class="isi">Terisi</label>
@endsection


@section('content')
    <div class="container-fluid container-fixed-lg">
        <div class="row">

            <div class="col-lg-12">
                @foreach($blocks as $block)
                <div class="panel panel-default">
                    <div class="panel-body" style="background: #FFF;">
                        <h5>Blok, {{ $block->name }},
                            <small class="pull-right m-t-10">
                                Jumlah: <b>{{ count($block->houses) }}</b> |
                                Terisi: <b>{{ count($block->housesIsi) }}</b> |
                                Akad: <b>{{ count($block->housesAkad) }}</b> |
                                Kosong: <b>{{ count($block->housesKosong) }}</b>
                            </small></h5>
                        <hr/>
                        <div>
                            <div class="row m-t-20">
                            @foreach($block->houses as $house)
                                    <div class="col-xs-4 col-md-1 col-sm-2 text-center">
                                        <div class="wrap {{ $house->status }}" data-placement="left"
                                             data-toggle="tooltip" title="{{ ucwords($house->status) }}">
                                            <div class="col-xs-4 indicator {{ ($house->indicator_satu) ? "done" : '' }}"
                                                 data-toggle="tooltip" title="{{ ($house->indicator_satu) ? " Oke" : 'Satu!' }}"></div>
                                            <div class="col-xs-4 indicator {{ ($house->indicator_dua) ? "done" : '' }}"
                                                 data-toggle="tooltip" title="{{ ($house->indicator_dua) ? " Oke" : 'Dua!' }}"></div>
                                            <div class="col-xs-4 indicator {{ ($house->indicator_tiga) ? "done" : '' }}"
                                                 data-toggle="tooltip" title="{{ ($house->indicator_tiga) ? "Oke" : 'Tiga!' }}"></div>
                                            <h5>{{ $house->number }}</h5>
                                        </div>
                                    </div>
                            @endforeach

                            </div>
                        </div>

                    </div>
                </div>
                @endforeach
            </div>

        </div>
    </div>
@endsection
