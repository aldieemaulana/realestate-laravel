<?php

namespace App\Http\Controllers\Manager;

use App\Block;
use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\House;
use Session;
use DB;
use Auth;
use File;

class DashboardController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('manager');
    }

    /**
     * Display a dashboard page.
     *
     * @return \Illuminate\View\View
     */
    public function dashboard()
    {
        $blocks = Block::all();
        return view('manager.page.dashboard.index', compact('blocks'));
    }

}
