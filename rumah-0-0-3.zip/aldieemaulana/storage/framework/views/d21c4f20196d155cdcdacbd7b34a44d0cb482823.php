<?php $__env->startSection('title', 'Transaction'); ?>
<?php $__env->startSection('description', 'Transaction Management'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid container-fixed-lg">
        <div class="row">

            <div class="col-lg-12">

                <div class="panel panel-default">
                    <div class="panel-heading">
                        <div class="panel-title">
                            <h4 class="m-t-0">Transaction</h4>
                        </div>

                    </div>
                    <div class="panel-body no-padding" style="background: #FFF">
                        <div class="row">
                            <table class="table table-hover de-left m-b-0 b-t-1">
                                <tbody>
                                <tr>
                                    <td width="15%">
                                        Action
                                    </td>
                                    <td>Nama</td>
                                    <td>Status</td>
                                    <td>Telepon</td>
                                    <td>Wawancara</td>
                                    <td>Booking Fee</td>
                                    <td>DP 1</td>
                                    <td>DP 2</td>
                                    <td>DP 3</td>
                                    <td>DP 4</td>
                                    <td>DP 5</td>
                                </tr>
                                <?php if(count($transactions)): ?>
                                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr id="<?php echo e($transaction->id); ?>">
                                            <td>
                                                <a onClick="deleteData(<?php echo e($transaction->id); ?>)" class="btn btn-default btn-rounded btn-xs" type="button" style="width:28px;height:28px;margin-right:4px;"><i class="fa fa-trash" style="width:8px;"></i></a>
                                                
                                            </td>
                                            <td class="font-montserrat fs-12 p-t-25" style="white-space: nowrap;"><?php echo e(ucwords($transaction->nama)); ?></td>
                                            <td class="font-montserrat fs-12 p-t-25" style="white-space: nowrap;"><?php echo e(ucwords($transaction->status)); ?></td>
                                            <td class="font-montserrat fs-12 p-t-25" style="white-space: nowrap;"><?php echo e(ucwords($transaction->telepon)); ?></td>
                                            <td class="font-montserrat fs-12 p-t-25" style="white-space: nowrap;"><?php echo e(ucwords($transaction->tanggal_wawancara)); ?></td>
                                            <td class="font-montserrat fs-12 p-t-25" style="white-space: nowrap;">Rp<?php echo e(number_format($transaction->booking_fee)); ?>,00,-</td>
                                            <td class="font-montserrat fs-12 p-t-25" style="white-space: nowrap;">Rp<?php echo e(number_format($transaction->dp1)); ?>,00,-</td>
                                            <td class="font-montserrat fs-12 p-t-25" style="white-space: nowrap;">Rp<?php echo e(number_format($transaction->dp2)); ?>,00,-</td>
                                            <td class="font-montserrat fs-12 p-t-25" style="white-space: nowrap;">Rp<?php echo e(number_format($transaction->dp3)); ?>,00,-</td>
                                            <td class="font-montserrat fs-12 p-t-25" style="white-space: nowrap;">Rp<?php echo e(number_format($transaction->dp4)); ?>,00,-</td>
                                            <td class="font-montserrat fs-12 p-t-25" style="white-space: nowrap;">Rp<?php echo e(number_format($transaction->dp5)); ?>,00,-</td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="2" style="background: #EEE;padding: 10px 20px;">
                                            Kosong
                                        </td>
                                    </tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                    <div class="panel-footer" style="background: #FFF;color: #101010;font-size: 13px;font-weight: 300">
                        <?php echo e((count($transactions) > 15) ? $transactions->links() : "Number of data: " . count($transactions)); ?>

                    </div>
                </div>
            </div>

        </div>
    </div>
    <input type="hidden" id="deleteID" />
<?php $__env->stopSection(); ?>


<?php $__env->startPush("script"); ?>
<script>

    function deleteData(id) {
        $('#modalDelete').modal('show');
        $('#deleteID').val(id);
    }

    function hapus(){
        $('#modalDelete').modal('hide');
        var id = $('#deleteID').val();
        $.ajax({
            url: '<?php echo e(url("manager/transaction")); ?>' + "/" + id + '?' + $.param({"_token" : '<?php echo e(csrf_token()); ?>' }),
            type: 'DELETE',
            complete: function(data) {
                $('#' + id).remove();
            }
        });
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('manager.layouts.frame', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>